/*
 * Lab4bdemo.c
 *
 * Created: 2026-02-17 2:53:28 PM
 * Author : kazoo
 */ 

#include <avr/interrupt.h>
#include <avr/io.h>

// define the global variables that can be used in every function ==========
volatile unsigned char ADC_result;
volatile unsigned int ADC_result_flag;

void main()
{
	cli(); // disable all of the interrupt ==========================
	
	
			// config the external interrupt ======================================
	EIMSK |= (_BV(INT2)); // enable INT2
	EICRA |= (_BV(ISC21) | _BV(ISC20)); // rising edge interrupt
			// config ADC =========================================================
	
		// by default, the ADC input (analog input is set to be ADC0 / PORTF0
	ADCSRA |= _BV(ADEN);		// enable ADC
	ADCSRA |= _BV(ADIE);		// enable interrupt of ADC
	
	//ADLAR- analog digital Left Adjust (register?), Does???
	//REFS0- reference selection(turn on capacitor at AVCC 
	ADMUX |= _BV(ADLAR) | _BV(REFS0); // Read Technical Manual & Complete Comment
	
		// set the PORTC as output to display the ADC result ==================
	
	DDRC = 0xff;
	
	// sets the Global Enable for all interrupts ==========================
	sei();
	
	// initialize the ADC, start one conversion at the beginning ==========
	ADCSRA |= _BV(ADSC);//analog digital start conversion
	
	while (1)
	{	if (ADC_result_flag)
		{
			PORTC = ADC_result;
			ADC_result_flag = 0x00;
		}
	}
} // end main


// sensor switch: Active HIGH starts AD converstion =======
ISR(INT2_vect)
{ // when there is a rising edge, we need to do ADC =====================
	ADCSRA |= _BV(ADSC);
}


// the interrupt will be trigured if the ADC is done ========================
ISR(ADC_vect)
{
	ADC_result = ADCH;
	ADC_result_flag = 1;
}
